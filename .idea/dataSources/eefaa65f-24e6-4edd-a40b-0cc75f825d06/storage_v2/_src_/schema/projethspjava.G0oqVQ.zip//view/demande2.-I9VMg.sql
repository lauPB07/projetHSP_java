create definer = projetHSP@`%` view demande2 as
select `d`.`description` AS `description`,
       `u`.`nom`         AS `nom`,
       `u`.`prenom`      AS `prenom`,
       `p`.`libelle`     AS `libelle`,
       `dp`.`nb`         AS `nb`,
       `dp`.`valider`    AS `valider`
from (((`projethspjava`.`demande` `d` join `projethspjava`.`utilisateur` `u`
        on ((`u`.`id_utilisateur` = `d`.`ref_userDemandeur`))) join `projethspjava`.`demandeproduit` `dp`
       on ((`dp`.`ref_demande` = `d`.`id_demande`))) join `projethspjava`.`ficheproduit` `p`
      on ((`p`.`id_ficheProduit` = `dp`.`ref_produit`)));

